﻿Public Class Form12
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        Dim a As Form3 = New Form3()
        a.Show()
    End Sub

    Private Sub Form12_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'ProyectoBDDataSet.ViewJornada' Puede moverla o quitarla según sea necesario.
        Me.ViewJornadaTableAdapter.Fill(Me.ProyectoBDDataSet.ViewJornada)

    End Sub
End Class