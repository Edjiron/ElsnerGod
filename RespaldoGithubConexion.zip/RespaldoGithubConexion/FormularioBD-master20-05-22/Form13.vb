﻿Public Class Form13
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        Dim a As Form3 = New Form3()
        a.Show()
    End Sub

    Private Sub Form13_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'ProyectoBDDataSet.ViewAsistencia' Puede moverla o quitarla según sea necesario.
        Me.ViewAsistenciaTableAdapter.Fill(Me.ProyectoBDDataSet.ViewAsistencia)

    End Sub
End Class