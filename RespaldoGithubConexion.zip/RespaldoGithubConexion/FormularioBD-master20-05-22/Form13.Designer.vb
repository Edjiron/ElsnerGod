﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form13
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ProyectoBDDataSet = New InterfasBD.ProyectoBDDataSet()
        Me.ViewAsistenciaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ViewAsistenciaTableAdapter = New InterfasBD.ProyectoBDDataSetTableAdapters.ViewAsistenciaTableAdapter()
        Me.FechaEntradaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IdEmpleadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaSalidaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalDiasTrabajadosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalDiasVacacionesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TotalDiasPermisosDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HoraEntradaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HoraSalidaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HorarioSalidaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HorarioEntradaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaInPermisoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaOffInicioDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MotivoPermisoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OffVacacionesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InVacacionesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProyectoBDDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ViewAsistenciaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.DataGridView1)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(518, 400)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Asistencia"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(431, 317)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Atras"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(12, 317)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Ver"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.FechaEntradaDataGridViewTextBoxColumn, Me.IdEmpleadoDataGridViewTextBoxColumn, Me.FechaSalidaDataGridViewTextBoxColumn, Me.TotalDiasTrabajadosDataGridViewTextBoxColumn, Me.TotalDiasVacacionesDataGridViewTextBoxColumn, Me.TotalDiasPermisosDataGridViewTextBoxColumn, Me.HoraEntradaDataGridViewTextBoxColumn, Me.HoraSalidaDataGridViewTextBoxColumn, Me.HorarioSalidaDataGridViewTextBoxColumn, Me.HorarioEntradaDataGridViewTextBoxColumn, Me.FechaInPermisoDataGridViewTextBoxColumn, Me.FechaOffInicioDataGridViewTextBoxColumn, Me.MotivoPermisoDataGridViewTextBoxColumn, Me.OffVacacionesDataGridViewTextBoxColumn, Me.InVacacionesDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ViewAsistenciaBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(23, 149)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(401, 150)
        Me.DataGridView1.TabIndex = 11
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(114, 61)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(185, 22)
        Me.TextBox1.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 17)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "ID empleado:"
        '
        'ProyectoBDDataSet
        '
        Me.ProyectoBDDataSet.DataSetName = "ProyectoBDDataSet"
        Me.ProyectoBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ViewAsistenciaBindingSource
        '
        Me.ViewAsistenciaBindingSource.DataMember = "ViewAsistencia"
        Me.ViewAsistenciaBindingSource.DataSource = Me.ProyectoBDDataSet
        '
        'ViewAsistenciaTableAdapter
        '
        Me.ViewAsistenciaTableAdapter.ClearBeforeFill = True
        '
        'FechaEntradaDataGridViewTextBoxColumn
        '
        Me.FechaEntradaDataGridViewTextBoxColumn.DataPropertyName = "fechaEntrada"
        Me.FechaEntradaDataGridViewTextBoxColumn.HeaderText = "fechaEntrada"
        Me.FechaEntradaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaEntradaDataGridViewTextBoxColumn.Name = "FechaEntradaDataGridViewTextBoxColumn"
        Me.FechaEntradaDataGridViewTextBoxColumn.Width = 125
        '
        'IdEmpleadoDataGridViewTextBoxColumn
        '
        Me.IdEmpleadoDataGridViewTextBoxColumn.DataPropertyName = "id_Empleado"
        Me.IdEmpleadoDataGridViewTextBoxColumn.HeaderText = "id_Empleado"
        Me.IdEmpleadoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.IdEmpleadoDataGridViewTextBoxColumn.Name = "IdEmpleadoDataGridViewTextBoxColumn"
        Me.IdEmpleadoDataGridViewTextBoxColumn.Width = 125
        '
        'FechaSalidaDataGridViewTextBoxColumn
        '
        Me.FechaSalidaDataGridViewTextBoxColumn.DataPropertyName = "fechaSalida"
        Me.FechaSalidaDataGridViewTextBoxColumn.HeaderText = "fechaSalida"
        Me.FechaSalidaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaSalidaDataGridViewTextBoxColumn.Name = "FechaSalidaDataGridViewTextBoxColumn"
        Me.FechaSalidaDataGridViewTextBoxColumn.Width = 125
        '
        'TotalDiasTrabajadosDataGridViewTextBoxColumn
        '
        Me.TotalDiasTrabajadosDataGridViewTextBoxColumn.DataPropertyName = "totalDiasTrabajados"
        Me.TotalDiasTrabajadosDataGridViewTextBoxColumn.HeaderText = "totalDiasTrabajados"
        Me.TotalDiasTrabajadosDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.TotalDiasTrabajadosDataGridViewTextBoxColumn.Name = "TotalDiasTrabajadosDataGridViewTextBoxColumn"
        Me.TotalDiasTrabajadosDataGridViewTextBoxColumn.Width = 125
        '
        'TotalDiasVacacionesDataGridViewTextBoxColumn
        '
        Me.TotalDiasVacacionesDataGridViewTextBoxColumn.DataPropertyName = "totalDiasVacaciones"
        Me.TotalDiasVacacionesDataGridViewTextBoxColumn.HeaderText = "totalDiasVacaciones"
        Me.TotalDiasVacacionesDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.TotalDiasVacacionesDataGridViewTextBoxColumn.Name = "TotalDiasVacacionesDataGridViewTextBoxColumn"
        Me.TotalDiasVacacionesDataGridViewTextBoxColumn.Width = 125
        '
        'TotalDiasPermisosDataGridViewTextBoxColumn
        '
        Me.TotalDiasPermisosDataGridViewTextBoxColumn.DataPropertyName = "totalDiasPermisos"
        Me.TotalDiasPermisosDataGridViewTextBoxColumn.HeaderText = "totalDiasPermisos"
        Me.TotalDiasPermisosDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.TotalDiasPermisosDataGridViewTextBoxColumn.Name = "TotalDiasPermisosDataGridViewTextBoxColumn"
        Me.TotalDiasPermisosDataGridViewTextBoxColumn.Width = 125
        '
        'HoraEntradaDataGridViewTextBoxColumn
        '
        Me.HoraEntradaDataGridViewTextBoxColumn.DataPropertyName = "horaEntrada"
        Me.HoraEntradaDataGridViewTextBoxColumn.HeaderText = "horaEntrada"
        Me.HoraEntradaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HoraEntradaDataGridViewTextBoxColumn.Name = "HoraEntradaDataGridViewTextBoxColumn"
        Me.HoraEntradaDataGridViewTextBoxColumn.Width = 125
        '
        'HoraSalidaDataGridViewTextBoxColumn
        '
        Me.HoraSalidaDataGridViewTextBoxColumn.DataPropertyName = "horaSalida"
        Me.HoraSalidaDataGridViewTextBoxColumn.HeaderText = "horaSalida"
        Me.HoraSalidaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HoraSalidaDataGridViewTextBoxColumn.Name = "HoraSalidaDataGridViewTextBoxColumn"
        Me.HoraSalidaDataGridViewTextBoxColumn.Width = 125
        '
        'HorarioSalidaDataGridViewTextBoxColumn
        '
        Me.HorarioSalidaDataGridViewTextBoxColumn.DataPropertyName = "horarioSalida"
        Me.HorarioSalidaDataGridViewTextBoxColumn.HeaderText = "horarioSalida"
        Me.HorarioSalidaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HorarioSalidaDataGridViewTextBoxColumn.Name = "HorarioSalidaDataGridViewTextBoxColumn"
        Me.HorarioSalidaDataGridViewTextBoxColumn.Width = 125
        '
        'HorarioEntradaDataGridViewTextBoxColumn
        '
        Me.HorarioEntradaDataGridViewTextBoxColumn.DataPropertyName = "HorarioEntrada"
        Me.HorarioEntradaDataGridViewTextBoxColumn.HeaderText = "HorarioEntrada"
        Me.HorarioEntradaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HorarioEntradaDataGridViewTextBoxColumn.Name = "HorarioEntradaDataGridViewTextBoxColumn"
        Me.HorarioEntradaDataGridViewTextBoxColumn.Width = 125
        '
        'FechaInPermisoDataGridViewTextBoxColumn
        '
        Me.FechaInPermisoDataGridViewTextBoxColumn.DataPropertyName = "fechaInPermiso"
        Me.FechaInPermisoDataGridViewTextBoxColumn.HeaderText = "fechaInPermiso"
        Me.FechaInPermisoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaInPermisoDataGridViewTextBoxColumn.Name = "FechaInPermisoDataGridViewTextBoxColumn"
        Me.FechaInPermisoDataGridViewTextBoxColumn.Width = 125
        '
        'FechaOffInicioDataGridViewTextBoxColumn
        '
        Me.FechaOffInicioDataGridViewTextBoxColumn.DataPropertyName = "fechaOffInicio"
        Me.FechaOffInicioDataGridViewTextBoxColumn.HeaderText = "fechaOffInicio"
        Me.FechaOffInicioDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaOffInicioDataGridViewTextBoxColumn.Name = "FechaOffInicioDataGridViewTextBoxColumn"
        Me.FechaOffInicioDataGridViewTextBoxColumn.Width = 125
        '
        'MotivoPermisoDataGridViewTextBoxColumn
        '
        Me.MotivoPermisoDataGridViewTextBoxColumn.DataPropertyName = "motivoPermiso"
        Me.MotivoPermisoDataGridViewTextBoxColumn.HeaderText = "motivoPermiso"
        Me.MotivoPermisoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.MotivoPermisoDataGridViewTextBoxColumn.Name = "MotivoPermisoDataGridViewTextBoxColumn"
        Me.MotivoPermisoDataGridViewTextBoxColumn.Width = 125
        '
        'OffVacacionesDataGridViewTextBoxColumn
        '
        Me.OffVacacionesDataGridViewTextBoxColumn.DataPropertyName = "offVacaciones"
        Me.OffVacacionesDataGridViewTextBoxColumn.HeaderText = "offVacaciones"
        Me.OffVacacionesDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.OffVacacionesDataGridViewTextBoxColumn.Name = "OffVacacionesDataGridViewTextBoxColumn"
        Me.OffVacacionesDataGridViewTextBoxColumn.Width = 125
        '
        'InVacacionesDataGridViewTextBoxColumn
        '
        Me.InVacacionesDataGridViewTextBoxColumn.DataPropertyName = "inVacaciones"
        Me.InVacacionesDataGridViewTextBoxColumn.HeaderText = "inVacaciones"
        Me.InVacacionesDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.InVacacionesDataGridViewTextBoxColumn.Name = "InVacacionesDataGridViewTextBoxColumn"
        Me.InVacacionesDataGridViewTextBoxColumn.Width = 125
        '
        'Form13
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form13"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Ver asistencia"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProyectoBDDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ViewAsistenciaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents ProyectoBDDataSet As ProyectoBDDataSet
    Friend WithEvents ViewAsistenciaBindingSource As BindingSource
    Friend WithEvents ViewAsistenciaTableAdapter As ProyectoBDDataSetTableAdapters.ViewAsistenciaTableAdapter
    Friend WithEvents FechaEntradaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents IdEmpleadoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaSalidaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalDiasTrabajadosDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalDiasVacacionesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TotalDiasPermisosDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HoraEntradaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HoraSalidaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HorarioSalidaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HorarioEntradaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaInPermisoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaOffInicioDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MotivoPermisoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OffVacacionesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents InVacacionesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
