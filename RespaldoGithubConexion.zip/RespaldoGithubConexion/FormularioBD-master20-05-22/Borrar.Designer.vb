﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Borrar
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnSalirB = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.btnBorrarEm = New System.Windows.Forms.Button()
        Me.ProyectoBDDataSet = New InterfasBD.ProyectoBDDataSet()
        Me.ViewEmpleadoDBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ViewEmpleadoDTableAdapter = New InterfasBD.ProyectoBDDataSetTableAdapters.ViewEmpleadoDTableAdapter()
        Me.IdEmpleadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NomEmpleadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TelefonoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DireccionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NombreDepDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DescripcionDepDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HorarioSalidaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HorarioEntradaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaInPermisoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaOffInicioDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MotivoPermisoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.InVacacionesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.OffVacacionesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TipoCargoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProyectoBDDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ViewEmpleadoDBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnSalirB)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.DataGridView1)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.btnBorrarEm)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 15)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(531, 524)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Borrar Empleado"
        '
        'btnSalirB
        '
        Me.btnSalirB.Location = New System.Drawing.Point(423, 453)
        Me.btnSalirB.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSalirB.Name = "btnSalirB"
        Me.btnSalirB.Size = New System.Drawing.Size(100, 28)
        Me.btnSalirB.TabIndex = 4
        Me.btnSalirB.Text = "Salir"
        Me.btnSalirB.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(45, 161)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 17)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "ID Empleado"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IdEmpleadoDataGridViewTextBoxColumn, Me.NomEmpleadoDataGridViewTextBoxColumn, Me.TelefonoDataGridViewTextBoxColumn, Me.EmailDataGridViewTextBoxColumn, Me.DireccionDataGridViewTextBoxColumn, Me.NombreDepDataGridViewTextBoxColumn, Me.DescripcionDepDataGridViewTextBoxColumn, Me.HorarioSalidaDataGridViewTextBoxColumn, Me.HorarioEntradaDataGridViewTextBoxColumn, Me.FechaInPermisoDataGridViewTextBoxColumn, Me.FechaOffInicioDataGridViewTextBoxColumn, Me.MotivoPermisoDataGridViewTextBoxColumn, Me.InVacacionesDataGridViewTextBoxColumn, Me.OffVacacionesDataGridViewTextBoxColumn, Me.TipoCargoDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ViewEmpleadoDBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(8, 242)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.Size = New System.Drawing.Size(515, 185)
        Me.DataGridView1.TabIndex = 2
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(184, 161)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(240, 22)
        Me.TextBox1.TabIndex = 1
        '
        'btnBorrarEm
        '
        Me.btnBorrarEm.Location = New System.Drawing.Point(296, 453)
        Me.btnBorrarEm.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBorrarEm.Name = "btnBorrarEm"
        Me.btnBorrarEm.Size = New System.Drawing.Size(100, 28)
        Me.btnBorrarEm.TabIndex = 0
        Me.btnBorrarEm.Text = "Borrar"
        Me.btnBorrarEm.UseVisualStyleBackColor = True
        '
        'ProyectoBDDataSet
        '
        Me.ProyectoBDDataSet.DataSetName = "ProyectoBDDataSet"
        Me.ProyectoBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ViewEmpleadoDBindingSource
        '
        Me.ViewEmpleadoDBindingSource.DataMember = "ViewEmpleadoD"
        Me.ViewEmpleadoDBindingSource.DataSource = Me.ProyectoBDDataSet
        '
        'ViewEmpleadoDTableAdapter
        '
        Me.ViewEmpleadoDTableAdapter.ClearBeforeFill = True
        '
        'IdEmpleadoDataGridViewTextBoxColumn
        '
        Me.IdEmpleadoDataGridViewTextBoxColumn.DataPropertyName = "id_Empleado"
        Me.IdEmpleadoDataGridViewTextBoxColumn.HeaderText = "id_Empleado"
        Me.IdEmpleadoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.IdEmpleadoDataGridViewTextBoxColumn.Name = "IdEmpleadoDataGridViewTextBoxColumn"
        Me.IdEmpleadoDataGridViewTextBoxColumn.Width = 125
        '
        'NomEmpleadoDataGridViewTextBoxColumn
        '
        Me.NomEmpleadoDataGridViewTextBoxColumn.DataPropertyName = "nomEmpleado"
        Me.NomEmpleadoDataGridViewTextBoxColumn.HeaderText = "nomEmpleado"
        Me.NomEmpleadoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.NomEmpleadoDataGridViewTextBoxColumn.Name = "NomEmpleadoDataGridViewTextBoxColumn"
        Me.NomEmpleadoDataGridViewTextBoxColumn.Width = 125
        '
        'TelefonoDataGridViewTextBoxColumn
        '
        Me.TelefonoDataGridViewTextBoxColumn.DataPropertyName = "telefono"
        Me.TelefonoDataGridViewTextBoxColumn.HeaderText = "telefono"
        Me.TelefonoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.TelefonoDataGridViewTextBoxColumn.Name = "TelefonoDataGridViewTextBoxColumn"
        Me.TelefonoDataGridViewTextBoxColumn.Width = 125
        '
        'EmailDataGridViewTextBoxColumn
        '
        Me.EmailDataGridViewTextBoxColumn.DataPropertyName = "email"
        Me.EmailDataGridViewTextBoxColumn.HeaderText = "email"
        Me.EmailDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.EmailDataGridViewTextBoxColumn.Name = "EmailDataGridViewTextBoxColumn"
        Me.EmailDataGridViewTextBoxColumn.Width = 125
        '
        'DireccionDataGridViewTextBoxColumn
        '
        Me.DireccionDataGridViewTextBoxColumn.DataPropertyName = "direccion"
        Me.DireccionDataGridViewTextBoxColumn.HeaderText = "direccion"
        Me.DireccionDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.DireccionDataGridViewTextBoxColumn.Name = "DireccionDataGridViewTextBoxColumn"
        Me.DireccionDataGridViewTextBoxColumn.Width = 125
        '
        'NombreDepDataGridViewTextBoxColumn
        '
        Me.NombreDepDataGridViewTextBoxColumn.DataPropertyName = "nombreDep"
        Me.NombreDepDataGridViewTextBoxColumn.HeaderText = "nombreDep"
        Me.NombreDepDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.NombreDepDataGridViewTextBoxColumn.Name = "NombreDepDataGridViewTextBoxColumn"
        Me.NombreDepDataGridViewTextBoxColumn.Width = 125
        '
        'DescripcionDepDataGridViewTextBoxColumn
        '
        Me.DescripcionDepDataGridViewTextBoxColumn.DataPropertyName = "descripcionDep"
        Me.DescripcionDepDataGridViewTextBoxColumn.HeaderText = "descripcionDep"
        Me.DescripcionDepDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.DescripcionDepDataGridViewTextBoxColumn.Name = "DescripcionDepDataGridViewTextBoxColumn"
        Me.DescripcionDepDataGridViewTextBoxColumn.Width = 125
        '
        'HorarioSalidaDataGridViewTextBoxColumn
        '
        Me.HorarioSalidaDataGridViewTextBoxColumn.DataPropertyName = "horarioSalida"
        Me.HorarioSalidaDataGridViewTextBoxColumn.HeaderText = "horarioSalida"
        Me.HorarioSalidaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HorarioSalidaDataGridViewTextBoxColumn.Name = "HorarioSalidaDataGridViewTextBoxColumn"
        Me.HorarioSalidaDataGridViewTextBoxColumn.Width = 125
        '
        'HorarioEntradaDataGridViewTextBoxColumn
        '
        Me.HorarioEntradaDataGridViewTextBoxColumn.DataPropertyName = "HorarioEntrada"
        Me.HorarioEntradaDataGridViewTextBoxColumn.HeaderText = "HorarioEntrada"
        Me.HorarioEntradaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HorarioEntradaDataGridViewTextBoxColumn.Name = "HorarioEntradaDataGridViewTextBoxColumn"
        Me.HorarioEntradaDataGridViewTextBoxColumn.Width = 125
        '
        'FechaInPermisoDataGridViewTextBoxColumn
        '
        Me.FechaInPermisoDataGridViewTextBoxColumn.DataPropertyName = "fechaInPermiso"
        Me.FechaInPermisoDataGridViewTextBoxColumn.HeaderText = "fechaInPermiso"
        Me.FechaInPermisoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaInPermisoDataGridViewTextBoxColumn.Name = "FechaInPermisoDataGridViewTextBoxColumn"
        Me.FechaInPermisoDataGridViewTextBoxColumn.Width = 125
        '
        'FechaOffInicioDataGridViewTextBoxColumn
        '
        Me.FechaOffInicioDataGridViewTextBoxColumn.DataPropertyName = "fechaOffInicio"
        Me.FechaOffInicioDataGridViewTextBoxColumn.HeaderText = "fechaOffInicio"
        Me.FechaOffInicioDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaOffInicioDataGridViewTextBoxColumn.Name = "FechaOffInicioDataGridViewTextBoxColumn"
        Me.FechaOffInicioDataGridViewTextBoxColumn.Width = 125
        '
        'MotivoPermisoDataGridViewTextBoxColumn
        '
        Me.MotivoPermisoDataGridViewTextBoxColumn.DataPropertyName = "motivoPermiso"
        Me.MotivoPermisoDataGridViewTextBoxColumn.HeaderText = "motivoPermiso"
        Me.MotivoPermisoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.MotivoPermisoDataGridViewTextBoxColumn.Name = "MotivoPermisoDataGridViewTextBoxColumn"
        Me.MotivoPermisoDataGridViewTextBoxColumn.Width = 125
        '
        'InVacacionesDataGridViewTextBoxColumn
        '
        Me.InVacacionesDataGridViewTextBoxColumn.DataPropertyName = "inVacaciones"
        Me.InVacacionesDataGridViewTextBoxColumn.HeaderText = "inVacaciones"
        Me.InVacacionesDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.InVacacionesDataGridViewTextBoxColumn.Name = "InVacacionesDataGridViewTextBoxColumn"
        Me.InVacacionesDataGridViewTextBoxColumn.Width = 125
        '
        'OffVacacionesDataGridViewTextBoxColumn
        '
        Me.OffVacacionesDataGridViewTextBoxColumn.DataPropertyName = "offVacaciones"
        Me.OffVacacionesDataGridViewTextBoxColumn.HeaderText = "offVacaciones"
        Me.OffVacacionesDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.OffVacacionesDataGridViewTextBoxColumn.Name = "OffVacacionesDataGridViewTextBoxColumn"
        Me.OffVacacionesDataGridViewTextBoxColumn.Width = 125
        '
        'TipoCargoDataGridViewTextBoxColumn
        '
        Me.TipoCargoDataGridViewTextBoxColumn.DataPropertyName = "tipoCargo"
        Me.TipoCargoDataGridViewTextBoxColumn.HeaderText = "tipoCargo"
        Me.TipoCargoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.TipoCargoDataGridViewTextBoxColumn.Name = "TipoCargoDataGridViewTextBoxColumn"
        Me.TipoCargoDataGridViewTextBoxColumn.Width = 125
        '
        'Borrar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1067, 554)
        Me.Controls.Add(Me.GroupBox1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Borrar"
        Me.Text = "Editar"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProyectoBDDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ViewEmpleadoDBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents btnBorrarEm As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnSalirB As Button
    Friend WithEvents ProyectoBDDataSet As ProyectoBDDataSet
    Friend WithEvents ViewEmpleadoDBindingSource As BindingSource
    Friend WithEvents ViewEmpleadoDTableAdapter As ProyectoBDDataSetTableAdapters.ViewEmpleadoDTableAdapter
    Friend WithEvents IdEmpleadoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NomEmpleadoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TelefonoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DireccionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NombreDepDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DescripcionDepDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HorarioSalidaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HorarioEntradaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaInPermisoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaOffInicioDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MotivoPermisoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents InVacacionesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents OffVacacionesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TipoCargoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
