﻿Public Class Form3
    Private Sub EditarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditarToolStripMenuItem.Click

    End Sub

    Private Sub GestinarEmpleadoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GestinarEmpleadoToolStripMenuItem.Click

    End Sub

    Private Sub JornadaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JornadaToolStripMenuItem.Click
        Hide()
        Dim a As Form12 = New Form12()
        a.Show()
    End Sub

    Private Sub AgregarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem.Click
        Hide()
        Dim a As Form5 = New Form5()
        a.Show()
    End Sub

    Private Sub BorarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BorarToolStripMenuItem.Click
        Hide()
        Dim a As Borrar = New Borrar()
        a.Show()
    End Sub

    Private Sub EditarToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles EditarToolStripMenuItem1.Click
        Hide()
        Dim a As btnEditarEm = New btnEditarEm()
        a.Show()
    End Sub

    Private Sub AdminsitrarPermisoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdminsitrarPermisoToolStripMenuItem.Click
        Hide()
        Dim a As Form10 = New Form10()
        a.Show()
    End Sub

    Private Sub AdministrarVacacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdministrarVacacionesToolStripMenuItem.Click
        Hide()
        Dim a As Form2 = New Form2()
        a.Show()
    End Sub

    Private Sub AsistenciaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AsistenciaToolStripMenuItem.Click
        Hide()
        Dim a As Form13 = New Form13()
        a.Show()
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        Hide()
        Dim a As Form1 = New Form1()
        a.Show()

    End Sub

    Private Sub AgregarToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem1.Click
        Hide()
        Dim a As Form6 = New Form6()
        a.Show()
    End Sub

    Private Sub BorrarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BorrarToolStripMenuItem.Click
        Hide()
        Dim a As Form7 = New Form7()
        a.Show()
    End Sub

    Private Sub EditarToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles EditarToolStripMenuItem2.Click
        Hide()
        Dim a As Form8 = New Form8()
        a.Show()
    End Sub
End Class