﻿Public Class Form5
    Private Sub btnSalirEm_Click(sender As Object, e As EventArgs) Handles btnSalirEm.Click
        Hide()
        Dim a As Form3 = New Form3()
        a.Show()
    End Sub
End Class