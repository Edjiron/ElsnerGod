﻿Public Class btnEditarEm
    Private Sub btnEditar_Click(sender As Object, e As EventArgs) Handles btnEditar.Click
        Hide()
        Dim a As Form4 = New Form4()
        a.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        Dim a As Form3 = New Form3()
        a.Show()
    End Sub

    Private Sub btnEditarEm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'ProyectoBDDataSet.ViewEditEmpleado' Puede moverla o quitarla según sea necesario.
        Me.ViewEditEmpleadoTableAdapter.Fill(Me.ProyectoBDDataSet.ViewEditEmpleado)

    End Sub
End Class