﻿Public Class Form7
    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        Dim a As Form3 = New Form3()
        a.Show()
    End Sub

    Private Sub Form7_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'ProyectoBDDataSet.ViewDepD' Puede moverla o quitarla según sea necesario.
        Me.ViewDepDTableAdapter.Fill(Me.ProyectoBDDataSet.ViewDepD)

    End Sub
End Class