﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form12
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.ProyectoBDDataSet = New InterfasBD.ProyectoBDDataSet()
        Me.ViewJornadaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ViewJornadaTableAdapter = New InterfasBD.ProyectoBDDataSetTableAdapters.ViewJornadaTableAdapter()
        Me.NomEmpleadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaEntradaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FechaSalidaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HorarioSalidaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.HorarioEntradaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DiaTrabajadoDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DiaDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProyectoBDDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ViewJornadaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(Me.DataGridView1)
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(32, 46)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(516, 384)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Ver jornada"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(435, 321)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Atras"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(16, 321)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Ver"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NomEmpleadoDataGridViewTextBoxColumn, Me.FechaEntradaDataGridViewTextBoxColumn, Me.FechaSalidaDataGridViewTextBoxColumn, Me.HorarioSalidaDataGridViewTextBoxColumn, Me.HorarioEntradaDataGridViewTextBoxColumn, Me.DiaTrabajadoDataGridViewTextBoxColumn, Me.DiaDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ViewJornadaBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(27, 131)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(401, 150)
        Me.DataGridView1.TabIndex = 4
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(82, 103)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 22)
        Me.DateTimePicker1.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(24, 103)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Fecha;"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(120, 65)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 22)
        Me.TextBox1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(24, 65)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID empleado:"
        '
        'ProyectoBDDataSet
        '
        Me.ProyectoBDDataSet.DataSetName = "ProyectoBDDataSet"
        Me.ProyectoBDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ViewJornadaBindingSource
        '
        Me.ViewJornadaBindingSource.DataMember = "ViewJornada"
        Me.ViewJornadaBindingSource.DataSource = Me.ProyectoBDDataSet
        '
        'ViewJornadaTableAdapter
        '
        Me.ViewJornadaTableAdapter.ClearBeforeFill = True
        '
        'NomEmpleadoDataGridViewTextBoxColumn
        '
        Me.NomEmpleadoDataGridViewTextBoxColumn.DataPropertyName = "nomEmpleado"
        Me.NomEmpleadoDataGridViewTextBoxColumn.HeaderText = "nomEmpleado"
        Me.NomEmpleadoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.NomEmpleadoDataGridViewTextBoxColumn.Name = "NomEmpleadoDataGridViewTextBoxColumn"
        Me.NomEmpleadoDataGridViewTextBoxColumn.Width = 125
        '
        'FechaEntradaDataGridViewTextBoxColumn
        '
        Me.FechaEntradaDataGridViewTextBoxColumn.DataPropertyName = "fechaEntrada"
        Me.FechaEntradaDataGridViewTextBoxColumn.HeaderText = "fechaEntrada"
        Me.FechaEntradaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaEntradaDataGridViewTextBoxColumn.Name = "FechaEntradaDataGridViewTextBoxColumn"
        Me.FechaEntradaDataGridViewTextBoxColumn.Width = 125
        '
        'FechaSalidaDataGridViewTextBoxColumn
        '
        Me.FechaSalidaDataGridViewTextBoxColumn.DataPropertyName = "fechaSalida"
        Me.FechaSalidaDataGridViewTextBoxColumn.HeaderText = "fechaSalida"
        Me.FechaSalidaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.FechaSalidaDataGridViewTextBoxColumn.Name = "FechaSalidaDataGridViewTextBoxColumn"
        Me.FechaSalidaDataGridViewTextBoxColumn.Width = 125
        '
        'HorarioSalidaDataGridViewTextBoxColumn
        '
        Me.HorarioSalidaDataGridViewTextBoxColumn.DataPropertyName = "horarioSalida"
        Me.HorarioSalidaDataGridViewTextBoxColumn.HeaderText = "horarioSalida"
        Me.HorarioSalidaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HorarioSalidaDataGridViewTextBoxColumn.Name = "HorarioSalidaDataGridViewTextBoxColumn"
        Me.HorarioSalidaDataGridViewTextBoxColumn.Width = 125
        '
        'HorarioEntradaDataGridViewTextBoxColumn
        '
        Me.HorarioEntradaDataGridViewTextBoxColumn.DataPropertyName = "HorarioEntrada"
        Me.HorarioEntradaDataGridViewTextBoxColumn.HeaderText = "HorarioEntrada"
        Me.HorarioEntradaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.HorarioEntradaDataGridViewTextBoxColumn.Name = "HorarioEntradaDataGridViewTextBoxColumn"
        Me.HorarioEntradaDataGridViewTextBoxColumn.Width = 125
        '
        'DiaTrabajadoDataGridViewTextBoxColumn
        '
        Me.DiaTrabajadoDataGridViewTextBoxColumn.DataPropertyName = "diaTrabajado"
        Me.DiaTrabajadoDataGridViewTextBoxColumn.HeaderText = "diaTrabajado"
        Me.DiaTrabajadoDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.DiaTrabajadoDataGridViewTextBoxColumn.Name = "DiaTrabajadoDataGridViewTextBoxColumn"
        Me.DiaTrabajadoDataGridViewTextBoxColumn.Width = 125
        '
        'DiaDataGridViewTextBoxColumn
        '
        Me.DiaDataGridViewTextBoxColumn.DataPropertyName = "dia"
        Me.DiaDataGridViewTextBoxColumn.HeaderText = "dia"
        Me.DiaDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.DiaDataGridViewTextBoxColumn.Name = "DiaDataGridViewTextBoxColumn"
        Me.DiaDataGridViewTextBoxColumn.Width = 125
        '
        'Form12
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form12"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ver jornada"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProyectoBDDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ViewJornadaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents ProyectoBDDataSet As ProyectoBDDataSet
    Friend WithEvents ViewJornadaBindingSource As BindingSource
    Friend WithEvents ViewJornadaTableAdapter As ProyectoBDDataSetTableAdapters.ViewJornadaTableAdapter
    Friend WithEvents NomEmpleadoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaEntradaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FechaSalidaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HorarioSalidaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents HorarioEntradaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DiaTrabajadoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DiaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
