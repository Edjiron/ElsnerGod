﻿Public Class Form8
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Hide()
        Dim a As Form3 = New Form3()
        a.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Hide()
        Dim a As Form9 = New Form9()
        a.Show()
    End Sub

    Private Sub Form8_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'ProyectoBDDataSet.VieweEditDep' Puede moverla o quitarla según sea necesario.
        Me.VieweEditDepTableAdapter.Fill(Me.ProyectoBDDataSet.VieweEditDep)

    End Sub
End Class