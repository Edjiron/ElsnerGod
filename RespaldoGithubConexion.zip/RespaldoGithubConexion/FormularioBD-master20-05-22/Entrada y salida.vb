﻿Public Class Entrada_y_salida
    Private Sub btnAtras_Click(sender As Object, e As EventArgs) Handles btnAtras.Click
        Hide()
        Dim a As Form1 = New Form1()
        a.Show()
    End Sub
End Class