﻿Public Class Form4
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub tbtAtrasEC_Click(sender As Object, e As EventArgs) Handles tbtAtrasEC.Click
        Hide()
        Dim a As btnEditarEm = New btnEditarEm()
        a.Show()
    End Sub
End Class